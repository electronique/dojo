

function secretfunction(){

     //Variables Declaration
var string1 = "this";
var string2 = "I";
var string3 = "can";

var num1 = 42;
var num2 = 43;
var num3 =44;
var num4 = 45;

var x;

var running = false;
var eating = true;

    console.log(string1,"is cool");
    console.log(string1,"is javascript");
    console.log(string2,string3,"do this" );
    console.log(num1,"is the secret");
    console.log(num2+num3-num4);
}